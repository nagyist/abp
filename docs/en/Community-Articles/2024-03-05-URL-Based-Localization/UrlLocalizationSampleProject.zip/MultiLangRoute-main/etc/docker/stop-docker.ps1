docker-compose down
exit $LASTEXITCODE