dotnet run --project MultiLangRoute --migrate-database

exit $LASTEXITCODE