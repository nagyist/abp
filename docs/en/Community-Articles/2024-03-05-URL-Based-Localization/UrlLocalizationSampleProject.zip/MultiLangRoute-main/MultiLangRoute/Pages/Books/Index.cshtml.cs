﻿using Microsoft.AspNetCore.Mvc.RazorPages;

namespace MultiLangRoute.Pages.Books;

public class IndexModel : PageModel
{
    public void OnGet()
    {

    }
}