﻿using Volo.Abp.AspNetCore.Mvc.UI.RazorPages;

namespace MultiLangRoute.Pages;

public class IndexModel : AbpPageModel
{
    
}