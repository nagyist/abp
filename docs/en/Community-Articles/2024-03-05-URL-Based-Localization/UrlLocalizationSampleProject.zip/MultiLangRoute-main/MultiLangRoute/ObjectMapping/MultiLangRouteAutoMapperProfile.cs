﻿using AutoMapper;
using MultiLangRoute.Entities.Books;
using MultiLangRoute.Services.Dtos.Books;

namespace MultiLangRoute.ObjectMapping;

public class MultiLangRouteAutoMapperProfile : Profile
{
    public MultiLangRouteAutoMapperProfile()
    {
        CreateMap<Book, BookDto>();
        CreateMap<CreateUpdateBookDto, Book>();
        CreateMap<BookDto, CreateUpdateBookDto>();
        /* Create your AutoMapper object mappings here */
    }
}
