using Volo.Abp.Application.Services;
using MultiLangRoute.Localization;

namespace MultiLangRoute.Services;

/* Inherit your application services from this class. */
public abstract class MultiLangRouteAppService : ApplicationService
{
    protected MultiLangRouteAppService()
    {
        LocalizationResource = typeof(MultiLangRouteResource);
    }
}