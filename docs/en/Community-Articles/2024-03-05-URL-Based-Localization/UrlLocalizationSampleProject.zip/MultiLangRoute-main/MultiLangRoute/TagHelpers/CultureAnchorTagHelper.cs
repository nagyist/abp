﻿using System.Web;
using Microsoft.AspNetCore.Razor.TagHelpers;
using MultiLangRoute.Routing;
using Volo.Abp.DependencyInjection;

namespace MultiLangRoute.TagHelpers;

/// <summary>
/// Tag helper that processes anchor tags to include culture information in URLs
/// </summary>
[HtmlTargetElement("a", Attributes = "href", TagStructure = TagStructure.NormalOrSelfClosing)]
public class CultureAnchorTagHelper(EndpointDataSource endpointDataSource, IHttpContextAccessor contextAccessor)
    : TagHelper, ITransientDependency
{
    /// <summary>
    /// Processes the anchor tag to normalize the URL with culture information
    /// </summary>
    /// <param name="context">The tag helper context</param>
    /// <param name="output">The tag helper output</param>
    public override void Process(TagHelperContext context, TagHelperOutput output)
    {
        var href = output.Attributes["href"].Value.ToString();
        if (href != null)
        {
            href = HttpUtility.UrlDecode(href);
            output.Attributes.SetAttribute("href",
                UrlNormalizer.NormalizeUrl(endpointDataSource, contextAccessor.HttpContext!, href));
        }
    }
}