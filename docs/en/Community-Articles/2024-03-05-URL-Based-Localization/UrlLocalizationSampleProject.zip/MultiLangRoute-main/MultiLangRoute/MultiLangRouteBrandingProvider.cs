using Microsoft.Extensions.Localization;
using MultiLangRoute.Localization;
using Volo.Abp.DependencyInjection;
using Volo.Abp.Ui.Branding;

namespace MultiLangRoute;

[Dependency(ReplaceServices = true)]
public class MultiLangRouteBrandingProvider : DefaultBrandingProvider
{
    private IStringLocalizer<MultiLangRouteResource> _localizer;

    public MultiLangRouteBrandingProvider(IStringLocalizer<MultiLangRouteResource> localizer)
    {
        _localizer = localizer;
    }

    public override string AppName => _localizer["AppName"];
}