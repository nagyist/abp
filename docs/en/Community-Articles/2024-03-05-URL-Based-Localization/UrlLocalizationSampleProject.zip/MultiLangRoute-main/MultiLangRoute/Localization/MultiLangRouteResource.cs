﻿using Volo.Abp.Localization;

namespace MultiLangRoute.Localization;

[LocalizationResourceName("MultiLangRoute")]
public class MultiLangRouteResource
{
    
}