﻿namespace MultiLangRoute.Menus;

public class MultiLangRouteMenus
{
    private const string Prefix = "MultiLangRoute";

    public const string Home = Prefix + ".Home";
}
