﻿using System.Collections.Concurrent;
using System.Globalization;
using Microsoft.Extensions.Primitives;
using Volo.Abp.DependencyInjection;

namespace MultiLangRoute.Routing;
/// <summary>
/// Custom link generator that adds language information to generated links
/// </summary>
/// <param name="serviceProvider">The service provider</param>
[ExposeServices(typeof(LinkGenerator))]
public class MyLinkGenerator(IServiceProvider serviceProvider) : LinkGenerator, ISingletonDependency
{
    private static readonly ConcurrentDictionary<string, string?> RouteNameCache = new(StringComparer.OrdinalIgnoreCase);
    private LinkGenerator? _linkGenerator;
    private LinkGenerator LinkGenerator {
        get
        {
            if (_linkGenerator != null)
            {
                return _linkGenerator;
            }
        
            var defaultLinkGenerator = serviceProvider.GetServices<LinkGenerator>().First(x => x is not MyLinkGenerator);
            return _linkGenerator = defaultLinkGenerator;
        }
    }
    
    /// <summary>
    /// Gets the path by address with language information
    /// </summary>
    public override string GetPathByAddress<TAddress>(HttpContext httpContext, TAddress address, RouteValueDictionary values,
        RouteValueDictionary? ambientValues = null, PathString? pathBase = null,
        FragmentString fragment = new(), LinkOptions? options = null)
    {
        return GetUrlByAddress(address, values, (newValues) => LinkGenerator.GetPathByAddress(httpContext, address, newValues, ambientValues, pathBase, fragment, options));
    }

    /// <summary>
    /// Gets the path by address with language information
    /// </summary>
    public override string GetPathByAddress<TAddress>(TAddress address, RouteValueDictionary values,
        PathString pathBase = new PathString(), FragmentString fragment = new FragmentString(),
        LinkOptions? options = null)
    {
        return GetUrlByAddress(address, values, (newValues) => LinkGenerator.GetPathByAddress(address, newValues, pathBase, fragment, options));
    }

    /// <summary>
    /// Gets the URI by address with language information
    /// </summary>
    public override string GetUriByAddress<TAddress>(HttpContext httpContext, TAddress address, RouteValueDictionary values,
        RouteValueDictionary? ambientValues = null, string? scheme = null, HostString? host = null,
        PathString? pathBase = null, FragmentString fragment = new FragmentString(), LinkOptions? options = null)
    {
        return GetUrlByAddress(address, values, (newValues) => LinkGenerator.GetUriByAddress(httpContext, address, newValues, ambientValues, scheme, host, pathBase, fragment, options));
    }

    /// <summary>
    /// Gets the URI by address with language information
    /// </summary>
    public override string GetUriByAddress<TAddress>(TAddress address, RouteValueDictionary values, string scheme, HostString host,
        PathString pathBase = new PathString(), FragmentString fragment = new FragmentString(),
        LinkOptions? options = null)
    {
        return GetUrlByAddress(address, values, (newValues) => LinkGenerator.GetUriByAddress(address, newValues, scheme, host, pathBase, fragment, options));
    }
    
    /// <summary>
    /// Adds language route values to the route values dictionary
    /// </summary>
    /// <typeparam name="TAddress">The address type</typeparam>
    /// <param name="address">The address</param>
    /// <param name="values">The route values</param>
    /// <returns>List of added route names</returns>
    private List<string> AddLanguageRouteValues<TAddress>(TAddress address, RouteValueDictionary values)
    {
        var addressingScheme = serviceProvider.GetRequiredService<IEndpointAddressScheme<TAddress>>();
        var routeNameList = addressingScheme.FindEndpoints(address)
            .Select(x => x.Metadata.GetMetadata<MultiLanguageSupportMetaData>()?.RouteName).Distinct().Where(x => x != null).Select(x => x!);

        return routeNameList.Where(routeName => values.TryAdd(routeName, CultureInfo.CurrentCulture.Name)).ToList();
    }
    
    /// <summary>
    /// Gets the URL by address with language information
    /// </summary>
    /// <typeparam name="TAddress">The address type</typeparam>
    /// <param name="address">The address</param>
    /// <param name="values">The route values</param>
    /// <param name="urlFactory">The URL factory function</param>
    /// <returns>The URL with language information</returns>
    private string GetUrlByAddress<TAddress>(TAddress address, RouteValueDictionary values, Func<RouteValueDictionary, string> urlFactory)
    {
        string[] requiredKeys = ["page", "area", "controller", "action"];
        string key;
        switch (address)
        {
            case RouteValuesAddress routeValuesAddress:
                key = string.Join("_", routeValuesAddress.ExplicitValues.Keys.Order());
                foreach (var requiredKey in requiredKeys)
                {
                    if(routeValuesAddress.ExplicitValues.TryGetValue(requiredKey, out var value))
                    {
                        key += $"_{requiredKey}={value}";
                    }
                }
                break;
            case string strAddress:
                key = strAddress;
                break;
            default:
                return GetUrlByAddressInternal(address, values, urlFactory, out _);
        }
        
        // Check cache for route name
        if(RouteNameCache.TryGetValue(key, out var routeName))
        {
            if (routeName != null)
            {
                values.TryAdd(routeName, CultureInfo.CurrentCulture.Name);
            }
            return urlFactory(values);
        }
        var url = GetUrlByAddressInternal(address, values, urlFactory, out routeName);
        RouteNameCache.TryAdd(key, routeName);
        return url;
    }
    
    /// <summary>
    /// Internal implementation to get URL by address with language information
    /// </summary>
    /// <typeparam name="TAddress">The address type</typeparam>
    /// <param name="address">The address</param>
    /// <param name="values">The route values</param>
    /// <param name="urlFactory">The URL factory function</param>
    /// <param name="routeName">The route name output parameter</param>
    /// <returns>The URL with language information</returns>
    private string GetUrlByAddressInternal<TAddress>(TAddress address, RouteValueDictionary values, Func<RouteValueDictionary, string> urlFactory, out string? routeName)
    {
        var addedRoutes = AddLanguageRouteValues(address, values);
        
        // Remove the extra added routes from the query string
        var url = urlFactory(values);
        routeName = null;
        if (addedRoutes.Count == 0)
        {
            return url;
        }
        var queryStartIndex = url.IndexOf('?');
        if(queryStartIndex < 0)
        {
            if (addedRoutes.Count == 1)
            {
                routeName = addedRoutes[0];
            }
            return url;
        }
        var queryEndIndex = url.IndexOf('#');
        if(queryEndIndex < 0)
        {
            queryEndIndex = url.Length;
        }
        var query = url.Substring(queryStartIndex, queryEndIndex - queryStartIndex);
        var queryCollection = Microsoft.AspNetCore.WebUtilities.QueryHelpers.ParseQuery(query);
        var deleted = false;
        var index = 0;
        while (index < addedRoutes.Count)
        {
            if (queryCollection.Remove(addedRoutes[index]))
            {
                deleted = true;
                addedRoutes.RemoveAt(index);
            }
            else
            {
                index++;
            }
        }

        if (addedRoutes.Count == 1)
        {
            routeName = addedRoutes[0];
        }
        
        if (!deleted)
        {
            return url;
        }
        
        url = url.Remove(queryStartIndex, queryEndIndex - queryStartIndex);
        
        return Microsoft.AspNetCore.WebUtilities.QueryHelpers.AddQueryString(url, queryCollection);
    }
}