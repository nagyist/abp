﻿using Microsoft.Extensions.Options;
using Volo.Abp.Localization;

namespace MultiLangRoute.Routing;

/// <summary>
/// Metadata that provides multi-language support for routes
/// </summary>
public class MultiLanguageSupportMetaData : IRedirectIfNeedsMetaData
{
    /// <summary>
    /// The name of the route parameter for language
    /// </summary>
    public string RouteName { get; private set; }
    
    /// <summary>
    /// The constraint name for the language route parameter
    /// </summary>
    public string Constraint { get; private set; }
    
    /// <summary>
    /// The route template for the language parameter
    /// </summary>
    public string RouteTemplate => "{" + RouteName + $":{Constraint}" + "}";

    /// <summary>
    /// The full route template including the language parameter
    /// </summary>
    public string? FullRouteTemplate { get; private set; }

    /// <summary>
    /// The index of the language parameter in the route
    /// </summary>
    public int RouteIndex { get; private set; }

    /// <summary>
    /// The route URL helper
    /// </summary>
    private MyRouteUrl MyRouteUrl { get; }
    
    /// <summary>
    /// Creates a new instance of MultiLanguageSupportMetaData
    /// </summary>
    /// <param name="oldFullRouteTemplate">The original route template</param>
    /// <param name="routeName">The name of the route parameter for language</param>
    /// <param name="constraint">The constraint name</param>
    /// <param name="routeIndex">The index of the language parameter in the route</param>
    public MultiLanguageSupportMetaData(string oldFullRouteTemplate, string routeName, string constraint, int routeIndex)
    {
        RouteName = routeName;
        Constraint = constraint;
        RouteIndex = routeIndex;
        MyRouteUrl = new MyRouteUrl(oldFullRouteTemplate, RouteUrlKind.RoutePattern);
        MyRouteUrl.Changed += (sender, args) =>
        {
            FullRouteTemplate = MyRouteUrl.GetUrl();
        };
        RouteIndex = MyRouteUrl.AddUniqueSegment(RouteTemplate, RouteIndex);
    }

    /// <summary>
    /// Rebuilds the URL with the specified culture
    /// </summary>
    /// <param name="url">The original URL</param>
    /// <param name="culture">The culture to include in the URL</param>
    /// <returns>The rebuilt URL with culture information</returns>
    public string RebuildUrl(string url, string culture)
    {
        return MyRouteUrl.ChangeSegment(url, RouteIndex, culture);
    }

    /// <summary>
    /// Determines if the context needs to be redirected based on culture
    /// </summary>
    /// <param name="context">The HTTP context</param>
    /// <returns>True if a redirect is needed, otherwise false</returns>
    public bool RedirectIfNeeds(HttpContext context)
    {
        var culture = GetCulture(context, out var originalCulture);
        if (originalCulture || culture == null)
        {
            return false;
        }
        
        context.Redirect(RebuildUrl(context.GetRequestPathAndQuery(), culture));
        return true;
    }

    /// <summary>
    /// Gets the culture from the HTTP context
    /// </summary>
    /// <param name="context">The HTTP context</param>
    /// <returns>The culture name</returns>
    public string? GetCulture(HttpContext context)
    {
        return GetCulture(context, out _);
    }

    /// <summary>
    /// Gets the culture from the HTTP context and determines if it's an original culture
    /// </summary>
    /// <param name="context">The HTTP context</param>
    /// <param name="originalCulture">Whether the culture is an original culture</param>
    /// <returns>The culture name</returns>
    private string? GetCulture(HttpContext context, out bool originalCulture)
    {
        var culture = GetCultureFromRouteValues(context, RouteName);

        var abpLocalizationOptions =
            context.RequestServices.GetRequiredService<IOptions<AbpLocalizationOptions>>().Value;
        originalCulture = abpLocalizationOptions.Languages.Any(x =>
            x.CultureName.Equals(culture, StringComparison.InvariantCulture));
        if (originalCulture)
        {
            return culture;
        }

        var newCulture = abpLocalizationOptions.Languages.FirstOrDefault(x =>
            x.TwoLetterISOLanguageName.Equals(culture, StringComparison.InvariantCultureIgnoreCase))?.CultureName;
        return string.IsNullOrEmpty(newCulture) ? null : newCulture;
    }

    /// <summary>
    /// Gets the culture from route values
    /// </summary>
    /// <param name="context">The HTTP context</param>
    /// <param name="routeValueName">The name of the route value</param>
    /// <returns>The culture name</returns>
    private static string? GetCultureFromRouteValues(HttpContext context, string routeValueName)
    {
        if (context.Request.RouteValues.TryGetValue(routeValueName, out var routeValue) &&
            routeValue is string routeValueString)
        {
            return routeValueString;
        }

        return null;
    }
}