﻿using Volo.Abp.AspNetCore.Middleware;
using Volo.Abp.DependencyInjection;

namespace MultiLangRoute.Routing;

/// <summary>
/// Middleware that handles routing and redirects for multi-language support
/// </summary>
public class RoutingMiddleware : AbpMiddlewareBase, ITransientDependency
{
    private static readonly IRedirectIfNeedsMetaData[] DefaultRedirectIfNeedsMetaDataList = [];
    
    /// <summary>
    /// Invokes the middleware
    /// </summary>
    /// <param name="context">The HTTP context</param>
    /// <param name="next">The next middleware in the pipeline</param>
    /// <returns>A task representing the asynchronous operation</returns>
    public override Task InvokeAsync(HttpContext context, RequestDelegate next)
    {
        var endpoint = context.GetEndpoint();
        if(endpoint is not RouteEndpoint)
        {
            return next(context);
        }
        
        // Check if the endpoint has redirect metadata
        var redirectMetaData = endpoint.Metadata.GetMetadata<IRedirectMetaData>();
        if (redirectMetaData is not null)
        {
            redirectMetaData.Redirect(context);
            return Task.CompletedTask;
        }

        // Check if any redirect-if-needs metadata indicates a redirect is needed
        var redirectIfNeedsMetaDataList = endpoint.Metadata
            .GetOrderedMetadata<IRedirectIfNeedsMetaData>()
            .Distinct()
            .Union(DefaultRedirectIfNeedsMetaDataList);
        if (redirectIfNeedsMetaDataList.Any(redirectIfNeedsMetaData => redirectIfNeedsMetaData.RedirectIfNeeds(context)))
        {
            return Task.CompletedTask;
        }

        return next(context);
    }
}