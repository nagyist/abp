﻿using Microsoft.AspNetCore.Localization;
using Microsoft.AspNetCore.RequestLocalization;

namespace MultiLangRoute.Routing;

/// <summary>
/// Request culture provider that determines culture from route data
/// </summary>
public class MyRouteDataRequestCultureProvider : RequestCultureProvider
{
    /// <summary>
    /// Determines the provider culture result from the HTTP context
    /// </summary>
    /// <param name="httpContext">The HTTP context</param>
    /// <returns>The provider culture result</returns>
    public override Task<ProviderCultureResult?> DetermineProviderCultureResult(HttpContext httpContext)
    {
        var endpoint = httpContext.GetEndpoint();
        if (endpoint?.Metadata.GetMetadata<MultiLanguageSupportMetaData>() is not { } multiLanguageSupportMetaData)
        {
            return Task.FromResult<ProviderCultureResult?>(null);
        }

        var culture = multiLanguageSupportMetaData.GetCulture(httpContext);
        
        if (culture == null)
        {
            return Task.FromResult<ProviderCultureResult?>(null);
        }
        
        // Set culture cookie
        AbpRequestCultureCookieHelper.SetCultureCookie(
            httpContext,
            new RequestCulture(culture)
        );
        
        return Task.FromResult<ProviderCultureResult?>(new ProviderCultureResult(culture));
    }
}