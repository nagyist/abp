﻿namespace MultiLangRoute.Routing;

/// <summary>
/// Interface for metadata that performs redirects
/// </summary>
public interface IRedirectMetaData
{
    /// <summary>
    /// Redirects the current HTTP context
    /// </summary>
    /// <param name="context">The HTTP context to redirect</param>
    void Redirect(HttpContext context);
}