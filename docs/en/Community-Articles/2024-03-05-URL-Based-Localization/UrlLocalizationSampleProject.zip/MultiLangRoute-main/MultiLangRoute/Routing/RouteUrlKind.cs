﻿namespace MultiLangRoute.Routing;

/// <summary>
/// Defines the kind of route URL
/// </summary>
public enum RouteUrlKind
{
    /// <summary>
    /// Represents a route pattern
    /// </summary>
    RoutePattern,
    
    /// <summary>
    /// Represents a regular URL
    /// </summary>
    Url
}