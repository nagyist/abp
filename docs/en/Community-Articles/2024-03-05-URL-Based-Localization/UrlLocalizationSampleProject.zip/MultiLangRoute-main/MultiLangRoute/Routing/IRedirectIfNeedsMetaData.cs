﻿namespace MultiLangRoute.Routing;

/// <summary>
/// Interface for metadata that determines if a redirect is needed
/// </summary>
public interface IRedirectIfNeedsMetaData
{
    /// <summary>
    /// Determines if the current context needs to be redirected
    /// </summary>
    /// <param name="context">The HTTP context</param>
    /// <returns>True if a redirect is needed, otherwise false</returns>
    bool RedirectIfNeeds(HttpContext context);
}