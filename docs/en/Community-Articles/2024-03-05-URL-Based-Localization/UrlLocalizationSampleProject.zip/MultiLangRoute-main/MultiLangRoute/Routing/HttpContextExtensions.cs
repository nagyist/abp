﻿using System.Text;

namespace MultiLangRoute.Routing;

/// <summary>
/// Extension methods for HttpContext to handle URL operations and redirections
/// </summary>
public static class HttpContextExtensions
{
    /// <summary>
    /// Redirects the current HTTP context to the specified URL
    /// </summary>
    /// <param name="context">The HTTP context</param>
    /// <param name="url">The URL to redirect to</param>
    public static void Redirect(this HttpContext context, string url) =>
        context.Response.Redirect(url, false, context.Request.Method != HttpMethods.Get);

    /// <summary>
    /// Rebuilds the URL with culture information if needed
    /// </summary>
    /// <param name="context">The HTTP context</param>
    /// <param name="culture">The culture to include in the URL</param>
    /// <returns>The rebuilt URL with culture information</returns>
    public static string ReBuildUrlWithCultureIfNeed(this HttpContext context, string culture)
    {
        var endpoint = context.GetEndpoint();
        var url = context.GetRequestPathAndQuery();

        return endpoint?.Metadata.GetMetadata<MultiLanguageSupportMetaData>()?.RebuildUrl(url, culture) ?? url;
    }
    
    /// <summary>
    /// Gets the full request path and query string from the HTTP context
    /// </summary>
    /// <param name="context">The HTTP context</param>
    /// <returns>The full request path and query string</returns>
    public static string GetRequestPathAndQuery(this HttpContext context)
    {
        var request = context.Request;
        var pathBase = request.PathBase.Value ?? string.Empty;
        var path = request.Path.Value ?? string.Empty;
        var queryString = request.QueryString.Value ?? string.Empty;

        // PERF: Calculate string length to allocate correct buffer size for StringBuilder.
        var length = pathBase.Length + path.Length + queryString.Length;

        return new StringBuilder(length)
            .Append(pathBase)
            .Append(path)
            .Append(queryString)
            .ToString();
    }
}