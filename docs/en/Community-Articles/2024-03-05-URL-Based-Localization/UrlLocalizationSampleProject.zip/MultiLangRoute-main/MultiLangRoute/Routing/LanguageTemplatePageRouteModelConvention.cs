﻿using Microsoft.AspNetCore.Mvc.ApplicationModels;

namespace MultiLangRoute.Routing;

/// <summary>
/// Page route model convention that adds language route templates to pages
/// </summary>
public class LanguageTemplatePageRouteModelConvention : IPageRouteModelConvention
{
    private const string LanguageRouteName = "language";
    private const int LanguageRouteIndex = 0;

    /// <summary>
    /// Applies the convention to the page route model
    /// </summary>
    /// <param name="model">The page route model</param>
    public void Apply(PageRouteModel model)
    {
        // Skip modal pages
        if(model.ViewEnginePath.EndsWith("modal", StringComparison.OrdinalIgnoreCase))
        {
            return;
        }
        
        var newSelectors = new List<SelectorModel>();
        foreach (var selector in model.Selectors)
        {
            if (selector.AttributeRouteModel?.Template == null)
            {
                continue;
            }
            
            var template = TransformPageRoute(model, selector);
            
            if (template == null)
            {
                continue;
            }
            
            // Create metadata for multi-language support
            var multiLanguageSupportMetaData = new MultiLanguageSupportMetaData(template, LanguageRouteName, LanguageRouteConstraint.Name, LanguageRouteIndex);

            // Create a new selector with the language route template
            var newSelector = new SelectorModel
            {
                AttributeRouteModel = new AttributeRouteModel
                {
                    Template = multiLanguageSupportMetaData.FullRouteTemplate,
                    Order = (selector.AttributeRouteModel.Order ?? 0) + (selector.EndpointMetadata.OfType<PageRouteMetadata>().Any() ? -1 : -2),
                    SuppressLinkGeneration = selector.AttributeRouteModel.SuppressLinkGeneration,
                }
            };
            
            // Copy endpoint metadata
            foreach (var endpointMetadata in selector.EndpointMetadata)
            {
                newSelector.EndpointMetadata.Add(endpointMetadata);
            }
            
            // Add multi-language support metadata
            newSelector.EndpointMetadata.Add(multiLanguageSupportMetaData);

            newSelectors.Add(newSelector);
            selector.EndpointMetadata.Add(new MultiLanguageRedirectRequiredMetaData(multiLanguageSupportMetaData));
        }
        
        // Add new selectors to the model
        foreach (var selector in newSelectors)
        {
            model.Selectors.Add(selector);
        }
    }

    // Based on ASP.NET Core's PageActionDescriptorProvider
    // https://github.com/dotnet/aspnetcore/blob/d581e015cb00a5f428aab0a31689176e604b0a13/src/Mvc/Mvc.RazorPages/src/Infrastructure/PageActionDescriptorProvider.cs#L127
    /// <summary>
    /// Transforms the page route using the route parameter transformer
    /// </summary>
    /// <param name="model">The page route model</param>
    /// <param name="selectorModel">The selector model</param>
    /// <returns>The transformed route template</returns>
    private static string? TransformPageRoute(PageRouteModel model, SelectorModel selectorModel)
    {
        var template = selectorModel.AttributeRouteModel!.Template;
        if(template?.StartsWith('/') == true)
        {
            template = template[1..];
        }
        
        // Transformer not set on page route
        if (model.RouteParameterTransformer == null)
        {
            return template;
        }

        var pageRouteMetadata = selectorModel.EndpointMetadata.OfType<PageRouteMetadata>().SingleOrDefault();
        if (pageRouteMetadata == null)
        {
            // Selector does not have expected metadata
            // This selector was likely configured by AddPageRouteModelConvention
            // Use the existing explicitly configured template
            return template;
        }

        string?[] segments = pageRouteMetadata.PageRoute.Split('/');
        for (var i = 0; i < segments.Length; i++)
        {
            segments[i] = model.RouteParameterTransformer.TransformOutbound(segments[i]);
        }

        var transformedPageRoute = string.Join("/", segments);

        // Combine transformed page route with template
        return AttributeRouteModel.CombineTemplates(transformedPageRoute, pageRouteMetadata.RouteTemplate);
    }
}