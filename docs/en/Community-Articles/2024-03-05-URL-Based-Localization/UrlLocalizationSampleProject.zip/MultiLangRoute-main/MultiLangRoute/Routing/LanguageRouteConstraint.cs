using Microsoft.Extensions.Options;
using Volo.Abp.Localization;

namespace MultiLangRoute.Routing;

/// <summary>
/// Route constraint that validates if a language parameter matches a supported culture
/// </summary>
public class LanguageRouteConstraint : IRouteConstraint
{
    /// <summary>
    /// The name of the language constraint
    /// </summary>
    public const string Name = "language";
    
    /// <summary>
    /// Determines if the route value matches a supported language
    /// </summary>
    /// <param name="httpContext">The HTTP context</param>
    /// <param name="route">The router</param>
    /// <param name="routeKey">The route key</param>
    /// <param name="values">The route values</param>
    /// <param name="routeDirection">The route direction</param>
    /// <returns>True if the language is supported, otherwise false</returns>
    public bool Match(HttpContext? httpContext, IRouter? route, string routeKey, RouteValueDictionary values, RouteDirection routeDirection)
    {
        if (!values.TryGetValue(routeKey, out var value) || value is not string language)
        {
            return false;
        }

        var options = httpContext?.RequestServices.GetService<IOptions<AbpLocalizationOptions>>()?.Value;
        if (options == null)
        {
            return false;
        }
        
        var supportedCultures = options.Languages.Select(x => x.CultureName).Union(options.Languages.Select(x => x.TwoLetterISOLanguageName));
        return supportedCultures.Contains(language, StringComparer.OrdinalIgnoreCase);
    }
}