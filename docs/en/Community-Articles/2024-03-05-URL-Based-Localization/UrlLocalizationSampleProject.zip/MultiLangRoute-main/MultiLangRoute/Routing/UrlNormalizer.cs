﻿using System.Collections.Concurrent;
using Microsoft.AspNetCore.Mvc.Abstractions;
using Microsoft.AspNetCore.Routing.Template;

namespace MultiLangRoute.Routing;

/// <summary>
/// Static utility class for normalizing URLs with culture information
/// </summary>
public static class UrlNormalizer
{
    private static readonly ConcurrentDictionary<string, MultiLanguageRedirectRequiredMetaData?> MultiLanguageRedirectRequiredMetaDataCache = new(StringComparer.OrdinalIgnoreCase);
    
    private const int MaxCacheSize = 10000;
    private static readonly ConcurrentDictionary<string, string> Cache = new();

    /// <summary>
    /// Normalizes a URL by adding culture information if needed
    /// </summary>
    /// <param name="endpointDataSource">The endpoint data source</param>
    /// <param name="httpContext">The HTTP context</param>
    /// <param name="url">The URL to normalize</param>
    /// <returns>The normalized URL with culture information</returns>
    public static string NormalizeUrl(EndpointDataSource endpointDataSource, HttpContext httpContext, string url)
    {
        if(string.IsNullOrWhiteSpace(url))
        {
            return url;
        }

        if(url.StartsWith("javascript:", StringComparison.OrdinalIgnoreCase))
        {
            return url;
        }
        
        // Manage cache size
        if (Cache.Count > MaxCacheSize)
        {
            // remove the 10% of the cache
            const int toRemove = (int)(MaxCacheSize * 0.1);
            foreach (var key in Cache.Keys.Take(toRemove))
            {
                Cache.TryRemove(key, out _);
            }
        }
        
        return Cache.GetOrAdd(url, (key) =>
        {
            var absoluteUrl = GetAbsoluteUrl(key);
            var multiLanguageRedirectRequiredMetaData =
                GetMultiLanguageRedirectRequiredMetaData(endpointDataSource, absoluteUrl);
            return multiLanguageRedirectRequiredMetaData?.ReBuildUrl(httpContext, key) ?? key;
        });
    }

    /// <summary>
    /// Converts a relative URL to an absolute URL path
    /// </summary>
    /// <param name="url">The URL to convert</param>
    /// <returns>The absolute URL path</returns>
    private static string? GetAbsoluteUrl(string? url)
    {
        if(string.IsNullOrWhiteSpace(url))
        {
            return url;
        }
        
        if (url[0] == '~')
        {
            url = url[1..];
        }
        
        if(url.Length == 0)
        {
            return url;
        }

        if (url[0] != '/')
        {
            var uri = new Uri(url);
            url = uri.AbsolutePath + uri.Query + uri.Fragment;
        }

        return url;
    }

    /// <summary>
    /// Gets the multi-language redirect metadata for a path
    /// </summary>
    /// <param name="endpointDataSource">The endpoint data source</param>
    /// <param name="path">The path to get metadata for</param>
    /// <returns>The multi-language redirect metadata, or null if not found</returns>
    private static MultiLanguageRedirectRequiredMetaData? GetMultiLanguageRedirectRequiredMetaData(
        EndpointDataSource endpointDataSource, string path)
    {
        // Check cache first
        if (MultiLanguageRedirectRequiredMetaDataCache.TryGetValue(path, out var foundMetaData))
        {
            return foundMetaData;
        }

        // Find endpoints with multi-language redirect metadata
        var endpoints = endpointDataSource.Endpoints.OfType<RouteEndpoint>().Where(x =>
            x.Metadata.GetMetadata<MultiLanguageRedirectRequiredMetaData>() != null);

        foreach (var endpoint in endpoints)
        {
            var routeValues = new RouteValueDictionary(endpoint.Metadata.GetMetadata<ActionDescriptor>()?.RouteValues ??
                                                       new Dictionary<string, string>()!);
            var templateMatcher =
                new TemplateMatcher(new RouteTemplate(endpoint.RoutePattern), new RouteValueDictionary());

            // Try to match the path to the endpoint's route template
            if (!templateMatcher.TryMatch(path, routeValues))
            {
                continue;
            }

            var multiLanguageRedirectRequiredMetaData =
                endpoint.Metadata.GetMetadata<MultiLanguageRedirectRequiredMetaData>();

            // Cache the result and return
            MultiLanguageRedirectRequiredMetaDataCache[path] = multiLanguageRedirectRequiredMetaData;
            return multiLanguageRedirectRequiredMetaData;
        }

        // Cache null result and return
        MultiLanguageRedirectRequiredMetaDataCache[path] = null;
        return null;
    }
}