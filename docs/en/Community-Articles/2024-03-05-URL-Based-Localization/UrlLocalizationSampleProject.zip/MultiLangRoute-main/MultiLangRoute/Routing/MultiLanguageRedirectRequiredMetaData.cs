﻿using System.Globalization;

namespace MultiLangRoute.Routing;

/// <summary>
/// Metadata that handles redirects for multi-language support
/// </summary>
/// <param name="multiLanguageSupportMetaData">The multi-language support metadata</param>
public class MultiLanguageRedirectRequiredMetaData(
    MultiLanguageSupportMetaData multiLanguageSupportMetaData)
    : IRedirectMetaData
{
    /// <summary>
    /// Rebuilds the URL with the appropriate culture information
    /// </summary>
    /// <param name="httpContext">The HTTP context</param>
    /// <param name="url">The original URL</param>
    /// <returns>The rebuilt URL with culture information</returns>
    public string ReBuildUrl(HttpContext httpContext, string url)
    {
        var routeUrl = new MyRouteUrl(url);
        var segment = routeUrl[multiLanguageSupportMetaData.RouteIndex];
        var culture = multiLanguageSupportMetaData.GetCulture(httpContext);
        if (segment?.Equals(culture) == true)
        {
            return url;
        }
        
        routeUrl.AddSegment(culture ?? CultureInfo.CurrentUICulture.Name, multiLanguageSupportMetaData.RouteIndex);
        return routeUrl.GetUrl();
    }
    
    /// <summary>
    /// Redirects the context to the URL with appropriate culture information
    /// </summary>
    /// <param name="context">The HTTP context</param>
    public void Redirect(HttpContext context)
    {
        context.Redirect(ReBuildUrl(context, context.GetRequestPathAndQuery()));
    }
}