﻿using System.Text;

namespace MultiLangRoute.Routing;

/// <summary>
/// Helper class for manipulating route URLs
/// </summary>
public class MyRouteUrl
{
    /// <summary>
    /// Event that is triggered when the URL changes
    /// </summary>
    public event EventHandler? Changed;

    private List<string> _segments = [];
    private readonly RouteUrlKind _kind;
    private int _length;
    private int _segmentsStartIndex;
    private int _segmentsEndIndex;
    private string _originalUrl;
    private bool _isChanged;
    
    /// <summary>
    /// Creates a new instance of MyRouteUrl
    /// </summary>
    /// <param name="url">The URL to parse</param>
    /// <param name="kind">The kind of URL</param>
    public MyRouteUrl(string url, RouteUrlKind kind = RouteUrlKind.Url)
    {
        _kind = kind;
        _originalUrl = url;
        Initialize(url);
    }
    
    /// <summary>
    /// Changes a segment in a URL
    /// </summary>
    /// <param name="url">The original URL</param>
    /// <param name="index">The index of the segment to change</param>
    /// <param name="newValue">The new value for the segment</param>
    /// <returns>The URL with the changed segment</returns>
    public static string ChangeSegment(string url, int index, string newValue)
    {
        var segments = new MyRouteUrl(url);
        segments.ChangeSegment(newValue, index);
        return segments.GetUrl();
    }

    /// <summary>
    /// Gets a segment by index
    /// </summary>
    /// <param name="index">The index of the segment</param>
    /// <returns>The segment at the specified index</returns>
    public string this[int index] => GetSegment(index);

    /// <summary>
    /// Triggers the Changed event
    /// </summary>
    /// <param name="addedSegment">The segment that was added</param>
    /// <param name="removedSegment">The segment that was removed</param>
    private void OnChanged(string? addedSegment = null, string? removedSegment = null)
    {
        _isChanged = true;
        if (addedSegment != null)
        {
            _length += addedSegment.Length + 1; // +1 for /
        }
        if (removedSegment != null)
        {
            _length -= removedSegment.Length + 1; // +1 for /
        }
        Changed?.Invoke(this, EventArgs.Empty);
    }
    
    /// <summary>
    /// Adds a unique segment to the URL
    /// </summary>
    /// <param name="segment">The segment to add</param>
    /// <param name="index">The index at which to add the segment</param>
    /// <returns>The index at which the segment was added</returns>
    public int AddUniqueSegment(string segment, int index)
    {
        RemoveSegment(segment);

        return AddSegment(segment, index);
    }
    
    /// <summary>
    /// Adds a segment to the URL
    /// </summary>
    /// <param name="segment">The segment to add</param>
    /// <param name="index">The index at which to add the segment</param>
    /// <returns>The index at which the segment was added</returns>
    public int AddSegment(string segment, int index)
    { 
        if (_kind == RouteUrlKind.RoutePattern && index > 0)
        {
            var catchAllIndex = GetCatchAllIndex();
            if (catchAllIndex != -1)
            {
                index = catchAllIndex;
            }
        }
        
        if(_segments.Count < index)
        {
            index = _segments.Count;
        }
        
        _segments.Insert(index, segment);
        OnChanged(addedSegment: segment);
        return index;
        
        // Find the index of a catch-all parameter
        int GetCatchAllIndex()
        {
            return _segments.FindIndex(x => x.StartsWith("{*", StringComparison.Ordinal)); //https://github.com/dotnet/aspnetcore/blob/main/src/Http/Routing/src/Patterns/RouteParameterParser.cs#L31 catch all parameter
        }
    }

    /// <summary>
    /// Removes a segment from the URL
    /// </summary>
    /// <param name="segment">The segment to remove</param>
    private void RemoveSegment(string segment)
    {
        if (_segments.Remove(segment))
        {
            OnChanged(removedSegment: segment);
        }
    }

    /// <summary>
    /// Changes a segment at the specified index
    /// </summary>
    /// <param name="segment">The new segment value</param>
    /// <param name="index">The index of the segment to change</param>
    private void ChangeSegment(string segment, int index)
    {
        if (index < 0 || index >= _segments.Count)
        {
            return;
        }

        var oldSegment = _segments[index];
        _segments[index] = segment;
        OnChanged(addedSegment: segment, removedSegment: oldSegment);
    }

    /// <summary>
    /// Gets a segment at the specified index
    /// </summary>
    /// <param name="index">The index of the segment</param>
    /// <returns>The segment at the specified index</returns>
    private string GetSegment(int index)
    {
        return index < 0 || index >= _segments.Count ? string.Empty : _segments[index];
    }
    
    /// <summary>
    /// Gets the full URL with any changes applied
    /// </summary>
    /// <returns>The full URL</returns>
    public string GetUrl()
    {
        if (!_isChanged)
        {
            return _originalUrl;
        }
        var sb = new StringBuilder(_length);
        sb.Append(_originalUrl[.._segmentsStartIndex]);
        if(sb.Length > 0 && sb[^1] != '/')
        {
            sb.Append('/');
        }
        sb.AppendJoin('/', _segments);
        sb.Append(_originalUrl[new Index(_segmentsEndIndex, true)..]);
        return sb.ToString();
    }
    
    /// <summary>
    /// Initializes the URL segments
    /// </summary>
    /// <param name="url">The URL to initialize from</param>
    private void Initialize(string url)
    {
        _originalUrl = url;
        _isChanged = false;
        _length = url.Length;
        SetStartIndex(url);
        SetEndIndex(url);
        _segmentsStartIndex = Math.Min(_segmentsStartIndex, url.Length);
        _segmentsEndIndex = Math.Min(_segmentsEndIndex, url.Length - _segmentsStartIndex);
        url = url[_segmentsStartIndex..new Index(_segmentsEndIndex, true)];
        string?[] segments = url.Split('/');
        _segments = new List<string>(segments.Length);
        foreach (var segment in segments)
        {
            if (string.IsNullOrWhiteSpace(segment))
            {
                continue;
            }
            _segments.Add(segment);
        }
        OnChanged();
    }
    
    /// <summary>
    /// Sets the start index for segments in the URL
    /// </summary>
    /// <param name="url">The URL</param>
    private void SetStartIndex(string url)
    {
        _segmentsStartIndex = 0;
        if(url.Length == 0)
        {
            _segmentsStartIndex = 0;
            return;
        }
        
        if(url[0] == '/')
        {
            _segmentsStartIndex = 1;
        }
        
        if(url[0] == '~')
        {
            if(url.Length > 1 && url[1] == '/')
            {
                _segmentsStartIndex = 2;
            }
            else
            {
                _segmentsStartIndex = 1;
            }
        }

        if (_kind == RouteUrlKind.RoutePattern)
        {
            return;
        }
        
        if (url.StartsWith(Uri.UriSchemeHttp) || url.StartsWith(Uri.UriSchemeHttps))
        {
            _segmentsStartIndex = new Uri(url).GetLeftPart(UriPartial.Authority).Length + 1;
        }
    }
    
    /// <summary>
    /// Sets the end index for segments in the URL
    /// </summary>
    /// <param name="url">The URL</param>
    private void SetEndIndex(string url)
    {
        _segmentsEndIndex = 0;
        if (url.Length == 0)
        {
            return;
        }
        
        if (url.Length > 1 && url[^1] == '/')
        {
            _segmentsEndIndex = 1;
        }

        if (_kind == RouteUrlKind.RoutePattern)
        {
            return;
        }
        
        var queryIndex = url.LastIndexOf('?');
        if (queryIndex != -1)
        {
            _segmentsEndIndex = url.Length - queryIndex;
            return;
        }
        
        var fragmentIndex = url.LastIndexOf('#');
        if (fragmentIndex != -1)
        {
            _segmentsEndIndex = url.Length - fragmentIndex;
        }
    }
}