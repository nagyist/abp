export const enum eUserMenuItems {
  MyAccount = 'UserMenu.MyAccount',
  Logout = 'UserMenu.Logout',
}
