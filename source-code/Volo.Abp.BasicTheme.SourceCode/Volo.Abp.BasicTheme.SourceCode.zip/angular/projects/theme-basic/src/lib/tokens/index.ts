export * from './lazy-styles.token';
