﻿using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Volo.Abp.AspNetCore.Mvc.UI.Bootstrap.Demo.Pages.Components;

public class GridsModel : PageModel
{
    public void OnGet()
    {

    }
}
