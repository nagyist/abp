export const enum eTenantManagementPolicyNames {
  TenantManagement = 'AbpTenantManagement.Tenants',
  Tenants = 'AbpTenantManagement.Tenants',
}
