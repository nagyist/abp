﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Volo.Abp.TenantManagement;

public class AbpTenantManagementDomainTestBase : TenantManagementTestBase<AbpSettingManagementDomainTestModule>
{

}
