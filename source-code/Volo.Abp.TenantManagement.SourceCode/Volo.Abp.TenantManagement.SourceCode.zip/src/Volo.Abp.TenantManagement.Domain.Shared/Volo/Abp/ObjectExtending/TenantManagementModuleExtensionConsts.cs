﻿namespace Volo.Abp.ObjectExtending;

public class TenantManagementModuleExtensionConsts
{
    public const string ModuleName = "TenantManagement";

    public static class EntityNames
    {
        public const string Tenant = "Tenant";
    }
}
