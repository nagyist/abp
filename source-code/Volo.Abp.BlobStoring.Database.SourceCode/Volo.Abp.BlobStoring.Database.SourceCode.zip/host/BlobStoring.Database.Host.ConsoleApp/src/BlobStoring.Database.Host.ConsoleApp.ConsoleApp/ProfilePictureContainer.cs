﻿namespace BlobStoring.Database.Host.ConsoleApp.ConsoleApp;

public class ProfilePictureContainer
{

}
