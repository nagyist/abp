﻿using Volo.Abp.Localization;


namespace Volo.Abp.IdentityServer.Localization;

[LocalizationResourceName("AbpIdentityServer")]
public class AbpIdentityServerResource
{
}
