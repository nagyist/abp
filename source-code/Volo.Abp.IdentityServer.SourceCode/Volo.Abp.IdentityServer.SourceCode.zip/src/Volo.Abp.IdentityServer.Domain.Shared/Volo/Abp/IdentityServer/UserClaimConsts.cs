﻿namespace Volo.Abp.IdentityServer;

public class UserClaimConsts
{
    /// <summary>
    /// Default value: 200
    /// </summary>
    public static int TypeMaxLength { get; set; } = 200;
}
