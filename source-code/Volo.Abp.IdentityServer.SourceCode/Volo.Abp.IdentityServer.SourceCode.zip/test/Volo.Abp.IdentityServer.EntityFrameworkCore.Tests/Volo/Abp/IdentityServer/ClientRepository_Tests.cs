﻿namespace Volo.Abp.IdentityServer;

public class ClientRepository_Tests : ClientRepository_Tests<AbpIdentityServerTestEntityFrameworkCoreModule>
{

}
