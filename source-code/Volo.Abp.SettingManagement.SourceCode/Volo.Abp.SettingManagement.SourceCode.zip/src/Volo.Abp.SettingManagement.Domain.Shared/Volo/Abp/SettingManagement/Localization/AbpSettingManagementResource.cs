﻿using Volo.Abp.Localization;

namespace Volo.Abp.SettingManagement.Localization;

[LocalizationResourceName("AbpSettingManagement")]
public class AbpSettingManagementResource
{

}
