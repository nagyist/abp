﻿using Volo.Abp.Localization;

namespace Volo.Abp.VirtualFileExplorer.Web.Localization;

[LocalizationResourceName("AbpVirtualFileExplorer")]
public class VirtualFileExplorerResource
{

}
