﻿using Volo.Abp.BlobStoring;

namespace Volo.Blogging
{
    [BlobContainerName("blogging-files")]
    public class BloggingFileContainer
    {

    }
}
