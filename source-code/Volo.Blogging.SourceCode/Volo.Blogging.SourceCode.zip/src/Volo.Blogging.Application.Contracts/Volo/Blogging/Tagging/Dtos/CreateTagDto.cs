﻿namespace Volo.Blogging.Tagging.Dtos
{
    public class CreateTagDto
    {
        public string Name { get; set; }

        public string Description { get; set; }
    }
}