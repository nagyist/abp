// This file is part of CommentsClientProxy, you can customize it here
// ReSharper disable once CheckNamespace
namespace Volo.Blogging;

public partial class CommentsClientProxy
{
}
