﻿namespace Volo.Blogging.Comments
{
    public class CommentConsts
    {
        /// <summary>
        /// Default value: 1024
        /// </summary>
        public static int MaxTextLength { get; set; } = 1024;
    }
}
