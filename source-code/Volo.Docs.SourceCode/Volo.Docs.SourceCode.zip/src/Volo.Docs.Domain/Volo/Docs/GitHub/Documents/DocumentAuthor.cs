﻿namespace Volo.Docs.GitHub.Documents
{
    public class DocumentAuthor
    {
        public string Login { get; set; }

        public string HtmlUrl { get; set; }

        public string AvatarUrl { get; set; }

        public int CommitCount { get; set; }
    }
}
