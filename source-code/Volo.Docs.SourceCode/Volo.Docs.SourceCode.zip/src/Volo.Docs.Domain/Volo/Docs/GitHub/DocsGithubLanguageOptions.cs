﻿using Volo.Docs.Documents;

namespace Volo.Docs.GitHub;

public class DocsGithubLanguageOptions
{
    public LanguageConfigElement DefaultLanguage { get; set; }
}