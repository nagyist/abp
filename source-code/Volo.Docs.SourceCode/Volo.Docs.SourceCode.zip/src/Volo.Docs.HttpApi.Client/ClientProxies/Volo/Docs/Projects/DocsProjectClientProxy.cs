// This file is part of DocsProjectClientProxy, you can customize it here
// ReSharper disable once CheckNamespace
namespace Volo.Docs.Projects;

public partial class DocsProjectClientProxy
{
}
