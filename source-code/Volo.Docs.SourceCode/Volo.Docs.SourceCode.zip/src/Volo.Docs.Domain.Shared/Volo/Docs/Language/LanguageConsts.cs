﻿
namespace Volo.Docs.Language
{
    public static class LanguageConsts
    {
        /// <summary>
        /// Default value: 10
        /// </summary>
        public static int MaxLanguageCodeLength { get; set; } = 10;
    }
}
