﻿namespace Volo.Abp.Account;

public static class AccountUrlNames
{
    public const string PasswordReset = "Abp.Account.PasswordReset";
}
