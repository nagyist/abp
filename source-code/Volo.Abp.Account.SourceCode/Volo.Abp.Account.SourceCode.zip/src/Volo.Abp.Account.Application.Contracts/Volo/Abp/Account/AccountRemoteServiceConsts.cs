﻿namespace Volo.Abp.Account;

public static class AccountRemoteServiceConsts
{
    public const string RemoteServiceName = "AbpAccount";

    public const string ModuleName = "account";
}
