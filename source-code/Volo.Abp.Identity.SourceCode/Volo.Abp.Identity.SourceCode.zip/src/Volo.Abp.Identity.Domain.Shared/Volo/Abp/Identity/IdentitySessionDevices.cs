namespace Volo.Abp.Identity;

public static class IdentitySessionDevices
{
    public const string Web = "Web";

    public const string OAuth = "OAuth";

    public const string Mobile = "Mobile";
}
