﻿namespace Volo.Abp.Identity.EntityFrameworkCore;

public class IdentityDataSeeder_Tests : IdentityDataSeeder_Tests<AbpIdentityEntityFrameworkCoreTestModule>
{

}
