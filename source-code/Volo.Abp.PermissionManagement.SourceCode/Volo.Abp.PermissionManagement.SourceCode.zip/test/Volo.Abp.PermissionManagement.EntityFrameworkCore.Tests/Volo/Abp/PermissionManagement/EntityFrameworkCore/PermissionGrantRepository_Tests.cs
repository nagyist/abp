﻿namespace Volo.Abp.PermissionManagement.EntityFrameworkCore;

public class PermissionGrantRepository_Tests : PermissionGrantRepository_Tests<AbpPermissionManagementEntityFrameworkCoreTestModule>
{

}
