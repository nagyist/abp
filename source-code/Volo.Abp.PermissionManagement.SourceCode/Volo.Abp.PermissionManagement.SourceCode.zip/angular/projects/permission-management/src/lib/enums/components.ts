export const enum ePermissionManagementComponents {
  PermissionManagement = 'PermissionManagement.PermissionManagementComponent',
}
