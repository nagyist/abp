﻿namespace Volo.Abp.PermissionManagement;

public class UpdatePermissionDto
{
    public string Name { get; set; }

    public bool IsGranted { get; set; }
}
