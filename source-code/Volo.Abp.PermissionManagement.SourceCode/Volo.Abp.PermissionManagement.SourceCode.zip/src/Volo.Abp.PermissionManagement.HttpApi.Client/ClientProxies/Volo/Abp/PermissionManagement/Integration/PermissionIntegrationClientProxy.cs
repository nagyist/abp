// This file is part of PermissionIntegrationClientProxy, you can customize it here
// ReSharper disable once CheckNamespace
namespace Volo.Abp.PermissionManagement.Integration;

public partial class PermissionIntegrationClientProxy
{
}
