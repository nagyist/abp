﻿namespace Volo.Abp.FeatureManagement;

public class FeatureManagementRemoteServiceConsts
{
    public const string RemoteServiceName = "AbpFeatureManagement";

    public const string ModuleName = "featureManagement";
}
