﻿namespace Volo.Abp.FeatureManagement;

public class UpdateFeatureDto
{
    public string Name { get; set; }

    public string Value { get; set; }
}
