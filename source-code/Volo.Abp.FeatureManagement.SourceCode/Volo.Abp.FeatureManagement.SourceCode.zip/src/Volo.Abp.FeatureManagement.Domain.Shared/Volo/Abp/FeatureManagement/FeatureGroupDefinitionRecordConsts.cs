namespace Volo.Abp.FeatureManagement;

public static class FeatureGroupDefinitionRecordConsts
{
    public static int MaxNameLength { get; set; } = 128;

    public static int MaxDisplayNameLength { get; set; } = 256;
}
