﻿namespace Volo.Abp.FeatureManagement.EntityFrameworkCore;

public class FeatureValueRepositoryTests : FeatureValueRepository_Tests<AbpFeatureManagementEntityFrameworkCoreTestModule>
{

}
