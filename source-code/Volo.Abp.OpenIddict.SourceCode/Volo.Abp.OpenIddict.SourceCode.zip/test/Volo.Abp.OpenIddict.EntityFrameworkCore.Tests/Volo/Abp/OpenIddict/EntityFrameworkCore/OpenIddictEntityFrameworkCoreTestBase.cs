﻿namespace Volo.Abp.OpenIddict.EntityFrameworkCore;

public abstract class OpenIddictEntityFrameworkCoreTestBase : OpenIddictTestBase<OpenIddictEntityFrameworkCoreTestModule>
{

}
