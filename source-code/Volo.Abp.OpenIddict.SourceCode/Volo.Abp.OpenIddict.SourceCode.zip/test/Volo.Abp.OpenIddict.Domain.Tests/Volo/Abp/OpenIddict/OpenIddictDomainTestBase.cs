﻿namespace Volo.Abp.OpenIddict;

public abstract class OpenIddictDomainTestBase : OpenIddictTestBase<OpenIddictDomainTestModule>
{

}
