namespace Volo.CmsKit.Menus;

public static class MenuApplicationConsts
{
    public static string MainMenuCacheKey = "MainMenu";
}
