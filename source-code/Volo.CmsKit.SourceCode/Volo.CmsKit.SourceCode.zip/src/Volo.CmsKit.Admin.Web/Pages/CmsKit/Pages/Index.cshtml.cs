﻿
namespace Volo.CmsKit.Admin.Web.Pages.CmsKit.Pages;

public class IndexModel : CmsKitAdminPageModel
{
    public void OnGet()
    {

    }
}
